import re
from collections import Counter


# 🔥 IMPROVED SKILL LIST (IMPORTANT)
COMMON_SKILLS = [
    "python","java","c","c++","sql","mysql","mongodb",
    "django","flask","react","node","nodejs",
    "html","css","javascript","bootstrap","tailwind",
    "api","rest","json",
    "machine learning","deep learning","ai",
    "data","data analysis","pandas","numpy",
    "excel","powerbi",
    "git","github","linux","aws","cloud"
]


# 🔥 CLEAN TEXT
def clean_text(text):
    return re.sub(r'[^a-zA-Z0-9\s]', ' ', text.lower())


# 🔥 EXTRACT KEYWORDS
def extract_keywords(text):
    text = clean_text(text)
    words = text.split()

    stopwords = {
        "the","and","for","with","this","that","are","you","your","have",
        "from","was","will","their","they","them","his","her","about",
        "into","over","after","before","between","within"
    }

    keywords = [w for w in words if w not in stopwords and len(w) > 2]

    freq = Counter(keywords)

    return [word for word, count in freq.most_common(50)]


# 🔥 🔥 FIXED SKILL EXTRACTION (KEY CHANGE)
def extract_skills(text):
    text = text.lower()

    skills = {}

    for skill in COMMON_SKILLS:
        # 🔥 phrase matching (IMPORTANT)
        count = text.count(skill)

        if count > 0:
            score = min(50 + count * 10, 100)
            skills[skill] = score

    return skills


# 🔥 MAIN FUNCTION
def analyze_resume(text, jd_text=None):

    text_lower = text.lower()

    # =========================
    # 🔥 SECTION DETECTION
    # =========================
    sections = {
        "skills": "skills" in text_lower,
        "projects": "project" in text_lower,
        "experience": "experience" in text_lower,
        "education": "education" in text_lower
    }

    weak_sections = [k for k, v in sections.items() if not v]

    section_score = sum(sections.values()) * 25

    # =========================
    # 🔥 SKILLS
    # =========================
    resume_skills = extract_skills(text)

    # =========================
    # 🔥 JD BASED
    # =========================
    if jd_text and jd_text.strip():

        jd_keywords = extract_keywords(jd_text)
        resume_keywords = extract_keywords(text)

        matched = list(set(jd_keywords) & set(resume_keywords))
        missing = list(set(jd_keywords) - set(resume_keywords))

        keyword_score = int((len(matched) / max(len(jd_keywords), 1)) * 100)

        relevance_boost = min(len(matched) * 2, 20)

        ats_score = int(
            (keyword_score * 0.5) +
            (section_score * 0.3) +
            relevance_boost
        )

        ats_score = max(30, min(ats_score, 100))

        skill_gap = missing[:10]

        interview_score = int(
            (ats_score * 0.6) +
            ((100 - len(skill_gap)*5) * 0.4)
        )

        interview_score = min(interview_score, 100)

        suggestions = []

        if keyword_score < 60:
            suggestions.append("Add more job-specific keywords")
        if weak_sections:
            suggestions.append("Improve sections: " + ", ".join(weak_sections))
        if len(skill_gap) > 5:
            suggestions.append("Reduce skill gap with relevant skills")

        return {
            "mode": "Smart JD Analysis",
            "ats_score": ats_score,
            "keyword_score": keyword_score,
            "missing_keywords": missing[:10],
            "skill_gap": skill_gap,
            "weak_sections": weak_sections,
            "interview_score": interview_score,
            "suggestions": suggestions or ["Good resume, minor improvements needed"],
            "skills": resume_skills
        }

    # =========================
    # 🔥 NO JD
    # =========================
    else:

        ats_score = int(section_score * 0.8)
        interview_score = int(ats_score * 0.75)

        suggestions = []

        for sec, present in sections.items():
            if not present:
                suggestions.append(f"Add {sec} section")

        if ats_score < 70:
            suggestions.append("Improve resume clarity and formatting")

        return {
            "mode": "Smart ATS Analysis",
            "ats_score": ats_score,
            "keyword_score": 0,
            "missing_keywords": [],
            "skill_gap": [],
            "weak_sections": weak_sections,
            "interview_score": interview_score,
            "suggestions": suggestions or ["Resume looks good"],
            "skills": resume_skills
        }