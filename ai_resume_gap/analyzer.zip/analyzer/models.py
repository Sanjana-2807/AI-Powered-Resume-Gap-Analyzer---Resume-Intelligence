from django.db import models
from django.contrib.auth.models import User


# 🔥 RESUME MODEL (MAIN)
class Resume(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    file = models.FileField(upload_to='resumes/')
    extracted_text = models.TextField(blank=True)

    # 🔥 AI SCORES
    ats_score = models.IntegerField(default=0)
    keyword_score = models.IntegerField(default=0)
    interview_score = models.IntegerField(default=0)

    # 🔥 ANALYSIS DATA
    missing_keywords = models.TextField(blank=True)
    skill_gap = models.TextField(blank=True)
    weak_sections = models.TextField(blank=True)

    # 🔥 NEW: SKILL STRENGTH (IMPORTANT)
    skills = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - Resume {self.id}"


# 🔥 JOB DESCRIPTION MODEL
class JobDescription(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()

    # 🔥 LINK JD WITH RESUME
    resume = models.ForeignKey(
        Resume,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - JD {self.id}"