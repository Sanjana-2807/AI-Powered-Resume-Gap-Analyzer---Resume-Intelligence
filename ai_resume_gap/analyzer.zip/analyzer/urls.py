from django.urls import path
from . import views

urlpatterns = [
    path('builder/', views.builder),
    path('dashboard/', views.dashboard),
    path('analysis/', views.analysis),
    path('insights/', views.insights),

    path('roadmap/', views.roadmap),
    path('evolution/', views.evolution),
    path('feedback/', views.feedback),

    # ✅ FIXED (added)
    path('interview/', views.interview),
    path('evolution/', views.evolution),
    path('admin-analytics/', views.admin_analytics, name='admin_analytics'),
]