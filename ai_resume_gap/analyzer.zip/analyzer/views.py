from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Resume, JobDescription
import PyPDF2
import json
from .ai_engine import analyze_resume


# ─────────────────────────────────────────────────────────────
# 🔥 BUILDER (UPLOAD + ANALYSIS)
# ─────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def builder(request):

    if request.method == 'POST':

        file = request.FILES.get('resume')
        jd_text = request.POST.get('jd')

        # ❌ NO FILE
        if not file:
            return render(request, 'pages/builder.html', {
                'error': 'Please upload a resume!'
            })

        # ❌ ONLY PDF
        if not file.name.endswith('.pdf'):
            return render(request, 'pages/builder.html', {
                'error': 'Only PDF files are allowed!'
            })

        # ✅ CREATE OBJECT
        resume_obj = Resume.objects.create(
            user=request.user,
            file=file
        )

        # 🔥 SAFE PDF READ
        try:
            pdf = PyPDF2.PdfReader(file)
            text = ""

            for page in pdf.pages:
                text += page.extract_text() or ""

        except Exception:
            resume_obj.delete()
            return render(request, 'pages/builder.html', {
                'error': 'Invalid or corrupted PDF file!'
            })

        # ✅ SAVE TEXT
        resume_obj.extracted_text = text

        # 🔥 SAVE JD (LINKED)
        if jd_text and jd_text.strip():
            JobDescription.objects.create(
                user=request.user,
                content=jd_text,
                resume=resume_obj
            )

        # 🔥 AI ANALYSIS
        result = analyze_resume(text, jd_text)

        # 🔥 SAVE SCORES
        resume_obj.ats_score = result.get("ats_score", 0)
        resume_obj.keyword_score = result.get("keyword_score", 0)
        resume_obj.interview_score = result.get("interview_score", 0)

        # 🔥 SAVE TEXT DATA
        resume_obj.missing_keywords = ",".join(result.get("missing_keywords", []))
        resume_obj.skill_gap = ",".join(result.get("skill_gap", []))
        resume_obj.weak_sections = ",".join(result.get("weak_sections", []))

        # 🔥 SAVE SKILLS
        resume_obj.skills = json.dumps(result.get("skills", {}))

        resume_obj.save()

        return redirect('/analyzer/analysis/')

    return render(request, 'pages/builder.html')


# ─────────────────────────────────────────────────────────────
# 🔥 HELPER FUNCTION
# ─────────────────────────────────────────────────────────────
def get_latest_resume(user):
    if user.is_authenticated:
        return Resume.objects.filter(user=user).order_by('-created_at').first()
    return None


# ─────────────────────────────────────────────────────────────
# 🔥 DASHBOARD
# ─────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def dashboard(request):
    return render(request, 'pages/dashboard.html')


# ─────────────────────────────────────────────────────────────
# 🔥 ANALYSIS PAGE
# ─────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def analysis(request):
    resume = get_latest_resume(request.user)

    weak_sections_list = []

    if resume and resume.weak_sections:
        weak_sections_list = [
            s.strip() for s in resume.weak_sections.split(',')
            if s.strip()
        ]

    return render(request, 'pages/analysis.html', {
        'resume': resume,
        'weak_sections_list': weak_sections_list
    })


# ─────────────────────────────────────────────────────────────
# 🔥 INSIGHTS PAGE
# ─────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def insights(request):
    resume = get_latest_resume(request.user)

    if not resume:
        return render(request, 'pages/insights.html', {'resume': None})

    weak_sections = resume.weak_sections.split(',') if resume.weak_sections else []
    missing_keywords = resume.missing_keywords.split(',') if resume.missing_keywords else []
    skill_gap = resume.skill_gap.split(',') if resume.skill_gap else []

    return render(request, 'pages/insights.html', {
        'resume': resume,
        'weak_sections': weak_sections,
        'missing_keywords': missing_keywords,
        'skill_gap': skill_gap
    })


# ─────────────────────────────────────────────────────────────
# 🔥 INTERVIEW PAGE
# ─────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def interview(request):
    resume = get_latest_resume(request.user)

    skills = {}

    if resume and resume.skills:
        try:
            skills = json.loads(resume.skills)
        except:
            skills = {}

    # 🔥 fallback
    if not skills:
        skills = {
            "communication": 60,
            "problem solving": 65
        }

    return render(request, 'pages/interview.html', {
        'resume': resume,
        'skills': skills
    })


# ─────────────────────────────────────────────────────────────
# 🔥 ROADMAP PAGE
# ─────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def roadmap(request):
    resume = get_latest_resume(request.user)

    if not resume:
        return render(request, 'pages/roadmap.html', {'resume': None})

    skill_gap = resume.skill_gap.split(',') if resume.skill_gap else []
    skill_gap = [s.strip() for s in skill_gap if s.strip()]

    total_skills = len(skill_gap)

    # 🔥 DURATION (2–4 WEEKS)
    if total_skills <= 2:
        weeks = 2
    elif total_skills <= 5:
        weeks = 3
    else:
        weeks = 4

    roadmap = []
    per_week = max(1, len(skill_gap) // weeks)

    for i in range(weeks):
        start = i * per_week
        end = start + per_week
        roadmap.append(skill_gap[start:end])

    return render(request, 'pages/roadmap.html', {
        'resume': resume,
        'roadmap': roadmap,
        'weeks': weeks,
        'total_skills': total_skills,
        'skill_gap': skill_gap
    })


# ─────────────────────────────────────────────────────────────
# 🔥 EVOLUTION PAGE
# ─────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def evolution(request):
    resumes = Resume.objects.filter(user=request.user).order_by('-created_at')

    return render(request, 'pages/evolution.html', {
        'resumes': resumes
    })


# ─────────────────────────────────────────────────────────────
# 🔥 FEEDBACK PAGE
# ─────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def feedback(request):
    return render(request, 'pages/feedback.html')

@login_required(login_url='/login/')
def admin_analytics(request):
    return render(request, 'pages/admin-analytics.html')