from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-azep(*!oyt)^46%q^$cx=^qad%t3s5uy5xwmpp)4l^rxp)dt4!'
DEBUG = True
ALLOWED_HOSTS = []


# ─── APPLICATIONS ────────────────────────────────────────────────────────────
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'users',
    'analyzer',
    'api',

    'social_django',
]


# ─── AUTH BACKENDS ────────────────────────────────────────────────────────────
AUTHENTICATION_BACKENDS = (
    'social_core.backends.google.GoogleOAuth2',
    'social_core.backends.linkedin.LinkedinOAuth2',
    'django.contrib.auth.backends.ModelBackend',
)


# ─── GOOGLE OAUTH ─────────────────────────────────────────────────────────────
SOCIAL_AUTH_GOOGLE_OAUTH2_KEY    = 'YOUR_GOOGLE_CLIENT_ID'
SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET = 'YOUR_GOOGLE_SECRET'

# ─── LINKEDIN OAUTH ───────────────────────────────────────────────────────────
SOCIAL_AUTH_LINKEDIN_OAUTH2_KEY    = 'YOUR_LINKEDIN_CLIENT_ID'
SOCIAL_AUTH_LINKEDIN_OAUTH2_SECRET = 'YOUR_LINKEDIN_SECRET'
SOCIAL_AUTH_LINKEDIN_OAUTH2_SCOPE  = ['r_liteprofile', 'r_emailaddress']


# ─── LOGIN / LOGOUT REDIRECTS ─────────────────────────────────────────────────
# After successful login (including social) go to builder
LOGIN_REDIRECT_URL  = '/analyzer/builder/'
LOGOUT_REDIRECT_URL = '/login/'

# ✅ KEY FIX: Django's built-in login_required will redirect here
LOGIN_URL = '/login/'


# ─── EMAIL (SMTP) ─────────────────────────────────────────────────────────────
EMAIL_BACKEND       = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST          = 'smtp.gmail.com'
EMAIL_PORT          = 587
EMAIL_USE_TLS       = True
EMAIL_HOST_USER     = 'your_email@gmail.com'
EMAIL_HOST_PASSWORD = 'your_app_password'


# ─── MIDDLEWARE ───────────────────────────────────────────────────────────────
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'social_django.middleware.SocialAuthExceptionMiddleware',   # ← social auth
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]


# ─── URL CONFIG ───────────────────────────────────────────────────────────────
ROOT_URLCONF = 'resume_gap_project.urls'


# ─── TEMPLATES ────────────────────────────────────────────────────────────────
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'social_django.context_processors.backends',
                'social_django.context_processors.login_redirect',
            ],
        },
    },
]


# ─── DATABASE ─────────────────────────────────────────────────────────────────
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'resume_ai_db',
        'USER': 'root',
        'PASSWORD': 'Negha@10',   # ⚠️ move to environment variable in production
        'HOST': 'localhost',
        'PORT': '3306',
    }
}


# ─── PASSWORD VALIDATION ──────────────────────────────────────────────────────
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]


# ─── STATIC & MEDIA ───────────────────────────────────────────────────────────
STATIC_URL       = '/static/'
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]

MEDIA_URL  = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'


DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


# ─── SESSION SETTINGS ─────────────────────────────────────────────────────────
# ✅ FIXED: SESSION_COOKIE_AGE = 0 was destroying sessions immediately.
#    Use a sensible timeout instead (e.g. 1 hour = 3600 seconds).
SESSION_COOKIE_AGE = 3600               # session lasts 1 hour of inactivity

# Close session when browser is closed (optional – set False if you want
# "Remember Me" to keep sessions alive across browser restarts)
SESSION_EXPIRE_AT_BROWSER_CLOSE = False  # ← set True only if you NEVER want persistence

SESSION_SAVE_EVERY_REQUEST = True        # ← resets the 1-hour timer on every request
