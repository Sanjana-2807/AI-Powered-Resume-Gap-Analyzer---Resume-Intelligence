from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),

    # ── App routes ──────────────────────────────────────────────────────────
    path('',          include('users.urls')),
    path('analyzer/', include('analyzer.urls')),
    path('api/',      include('api.urls')),

    # ── Social auth (Google + LinkedIn) ─────────────────────────────────────
    path('auth/', include('social_django.urls', namespace='social')),

    # ── Password-reset flow ──────────────────────────────────────────────────
    path('forgot-password/',
         auth_views.PasswordResetView.as_view(
             template_name='pages/forgot_password.html',
             email_template_name='emails/password_reset_email.html',
             subject_template_name='emails/password_reset_subject.txt',
         ),
         name='password_reset'),

    path('reset-password-sent/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='pages/password_reset_done.html'
         ),
         name='password_reset_done'),

    path('reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='pages/password_reset_confirm.html'
         ),
         name='password_reset_confirm'),

    path('reset-complete/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='pages/password_reset_complete.html'
         ),
         name='password_reset_complete'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
