from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Profile


# ─── HOME ─────────────────────────────────────────────────────────────────────
def home(request):
    return render(request, 'pages/home.html')


# ─── SIGNUP ───────────────────────────────────────────────────────────────────
def signup(request):
    # ✅ Already logged-in users go straight to builder
    if request.user.is_authenticated:
        return redirect('/analyzer/builder/')

    if request.method == 'POST':
        username         = request.POST.get('username', '').strip()
        email            = request.POST.get('email', '').strip()
        password         = request.POST.get('password', '')
        confirm_password = request.POST.get('confirm_password', '')

        # ── Validations ──────────────────────────────────────────────────────
        if not username or not email or not password:
            return render(request, 'pages/signup.html', {
                'error': 'All fields are required'
            })

        if len(username) < 3:
            return render(request, 'pages/signup.html', {
                'error': 'Username must be at least 3 characters'
            })

        if password != confirm_password:
            return render(request, 'pages/signup.html', {
                'error': 'Passwords do not match'
            })

        if len(password) < 8:
            return render(request, 'pages/signup.html', {
                'error': 'Password must be at least 8 characters'
            })

        if User.objects.filter(username=username).exists():
            return render(request, 'pages/signup.html', {
                'error': 'Username already taken'
            })

        if User.objects.filter(email=email).exists():
            return render(request, 'pages/signup.html', {
                'error': 'An account with that email already exists'
            })

        # ── Create & auto-login ──────────────────────────────────────────────
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
        return redirect('/analyzer/builder/')

    return render(request, 'pages/signup.html')


# ─── LOGIN ────────────────────────────────────────────────────────────────────
def login_view(request):
    # ✅ Already logged-in users go straight to builder
    if request.user.is_authenticated:
        return redirect('/analyzer/builder/')

    if request.method == 'POST':
        login_input = request.POST.get('username', '').strip()
        password    = request.POST.get('password', '')

        if not login_input or not password:
            return render(request, 'pages/login.html', {
                'error': 'Please enter your username/email and password'
            })

        # ── Support email login ───────────────────────────────────────────────
        if '@' in login_input:
            try:
                user_obj    = User.objects.get(email=login_input)
                login_input = user_obj.username
            except User.DoesNotExist:
                return render(request, 'pages/login.html', {
                    'error': 'Invalid username/email or password'
                })

        user = authenticate(request, username=login_input, password=password)

        if user is not None:
            from django.contrib.auth import login

            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            # ✅ Honour ?next= parameter (e.g. when redirected from @login_required)
            next_url = request.POST.get('next') or request.GET.get('next') or '/analyzer/builder/'
            return redirect(next_url)
        else:
            return render(request, 'pages/login.html', {
                'error': 'Invalid username/email or password'
            })
        
        

    return render(request, 'pages/login.html')


# ─── PROFILE ─────────────────────────────────────────────────────────────────
@login_required(login_url='/login/')
def profile(request):
    profile_obj, _ = Profile.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        profile_obj.full_name  = request.POST.get('full_name', '')
        profile_obj.skills     = request.POST.get('skills', '')
        profile_obj.education  = request.POST.get('education', '')
        profile_obj.save()
        return redirect('/profile/')

    return render(request, 'pages/profile.html', {
        'profile': profile_obj,
        'user': request.user
    })


# ─── LOGOUT ───────────────────────────────────────────────────────────────────
def logout_view(request):
    logout(request)
    return redirect('/login/')


